package com.reelguard.app

import android.app.Activity
import android.app.TimePickerDialog
import android.net.VpnService
import java.util.Calendar
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val vpnRequestCode = 8041
    private val vpnScheduleRequestCode = 8042
    private val bg = Color.rgb(9, 12, 24)
    private val panel = Color.rgb(21, 27, 47)
    private val panel2 = Color.rgb(29, 37, 63)
    private val ink = Color.rgb(244, 247, 255)
    private val muted = Color.rgb(157, 169, 196)
    private val cyan = Color.rgb(42, 220, 235)
    private val violet = Color.rgb(164, 104, 255)
    private val checks = linkedMapOf<String, CheckBox>()
    private val wholeChecks = linkedMapOf<String, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }
    override fun onResume() { super.onResume(); if (checks.isNotEmpty()) render() }

    private fun render() {
        checks.clear()
        wholeChecks.clear()
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); clipToPadding = false }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
            setBackgroundColor(bg)
        }
        scroll.addView(page)
        setContentView(scroll)

        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(22)); background = rounded(panel2, 26) }
        top.addView(label("REELGUARD", 13, cyan, true))
        top.addView(label("Take back your scroll.", 27, ink, true).apply { setPadding(0, dp(8), 0, dp(5)) })
        top.addView(label("Less endless video. More time for your real life.", 14, muted, false))
        top.addView(label("✦  FOCUS MODE  •  BUILT FOR YOU", 11, violet, true).apply { setPadding(0, dp(18), 0, 0) })
        page.addView(top, matchWrap())

        val permissionOk = isAccessibilityEnabled()
        val statusCard = card(page)
        statusCard.addView(label(if (permissionOk) "●  BLOCKER CONNECTED" else "○  PERMISSION NEEDED", 13, if (permissionOk) cyan else Color.rgb(255, 190, 95), true))
        statusCard.addView(label(if (permissionOk) "ReelGuard is ready to watch your selected feeds." else "Turn on the accessibility service to let ReelGuard detect selected feeds.", 13, muted, false).apply { setPadding(0, dp(7), 0, 0) })

        val forcedNow = BlockPreferences.isForcedNow(this)
        val modeCard = card(page)
        modeCard.addView(label("FOCUS CONTROL", 12, violet, true))
        modeCard.addView(label(if (forcedNow) "Forced Mode is active" else "Your blocker", 19, ink, true).apply { setPadding(0, dp(6), 0, dp(2)) })
        val master = Switch(this).apply {
            text = if (forcedNow) "Locked until scheduled session ends" else "Enable ReelGuard"
            textSize = 15f; setTextColor(ink)
            isChecked = BlockPreferences.effectiveEnabled(this@MainActivity)
            isEnabled = !forcedNow
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, checked -> BlockPreferences.setEnabled(this@MainActivity, checked) }
        }
        modeCard.addView(master)

        val schedule = Button(this).apply {
            text = if (BlockPreferences.scheduleEnabled(this@MainActivity)) "EDIT DAILY FOCUS SCHEDULE" else "＋  SET DAILY FOCUS SCHEDULE"
            styleButton(this, true)
            setOnClickListener { chooseSchedule() }
        }
        modeCard.addView(schedule, matchWrap())
        if (BlockPreferences.scheduleEnabled(this) && !forcedNow) {
            modeCard.addView(Button(this).apply {
                text = "REMOVE SCHEDULE"; styleButton(this, false)
                setOnClickListener {
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("Remove schedule?")
                        .setMessage("This removes upcoming daily Forced Mode sessions.")
                        .setNegativeButton("KEEP", null)
                        .setPositiveButton("REMOVE") { _, _ ->
                            BlockPreferences.setSchedule(this@MainActivity, false, BlockPreferences.scheduleStart(this@MainActivity), BlockPreferences.scheduleEnd(this@MainActivity))
                            render()
                        }.show()
                }
            }, matchWrap())
        }
        val scheduleText = if (BlockPreferences.scheduleEnabled(this)) {
            val modes = mutableListOf<String>()
            if (BlockPreferences.scheduleFeeds(this)) modes += "Short videos"
            if (BlockPreferences.scheduleWholeApps(this)) modes += "Entire selected apps"
            if (BlockPreferences.scheduleSafeMode(this)) modes += "Safe Mode"
            "Every day  •  ${formatMinutes(BlockPreferences.scheduleStart(this))} – ${formatMinutes(BlockPreferences.scheduleEnd(this))}\nScheduled protection: ${modes.joinToString(" + ").ifBlank { "None" }}. Settings stay locked during the session."
        }
        else "Set a daily window. Forced Mode turns on automatically and survives app restarts and phone reboots."
        modeCard.addView(label(scheduleText, 12, muted, false).apply { setPadding(0, dp(10), 0, 0) })

        val appsCard = card(page)
        appsCard.addView(label("YOUR BLOCK LIST", 12, violet, true))
        appsCard.addView(label("Choose the feeds you want out of your day.", 18, ink, true).apply { setPadding(0, dp(6), 0, dp(3)) })
        appsCard.addView(label("These choices block only the selected short-video feeds.", 12, muted, false).apply { setPadding(0, 0, 0, dp(10)) })
        val selected = BlockPreferences.selectedApps(this)
        addChoice(appsCard, "Instagram Reels", BlockPreferences.INSTAGRAM, selected, forcedNow, "IG")
        addChoice(appsCard, "Facebook Reels", BlockPreferences.FACEBOOK, selected, forcedNow, "f")
        addChoice(appsCard, "YouTube Shorts", BlockPreferences.YOUTUBE, selected, forcedNow, "▶")
        addChoice(appsCard, "TikTok For You", BlockPreferences.TIKTOK, selected, forcedNow, "♪")
        addChoice(appsCard, "Snapchat Spotlight", BlockPreferences.SNAPCHAT, selected, forcedNow, "✦")
        val save = Button(this).apply {
            text = "SAVE MY BLOCK LIST"; styleButton(this, true); isEnabled = !forcedNow
            setOnClickListener {
                if (BlockPreferences.isForcedNow(this@MainActivity)) {
                    android.widget.Toast.makeText(this@MainActivity, "Forced Mode is active; settings are locked until it ends.", android.widget.Toast.LENGTH_LONG).show(); return@setOnClickListener
                }
                BlockPreferences.setSelectedApps(this@MainActivity, checks.filterValues { it.isChecked }.keys)
                android.widget.Toast.makeText(this@MainActivity, "Block list saved.", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        appsCard.addView(save, matchWrap())

        val wholeCard = card(page)
        wholeCard.addView(label("WHOLE APP BLOCK", 12, violet, true))
        wholeCard.addView(label("Want a complete break? Select apps here to block opening them entirely, not just their short-video feeds.", 13, muted, false).apply { setPadding(0, dp(6), 0, dp(8)) })
        val wholeSelected = BlockPreferences.wholeApps(this)
        val wholeMaster = Switch(this).apply {
            text = "Enable whole-app blocking"; textSize = 14f; setTextColor(ink)
            isChecked = BlockPreferences.wholeAppBlockingEnabled(this@MainActivity)
            isEnabled = !forcedNow
            setOnCheckedChangeListener { _, checked ->
                if (!BlockPreferences.isForcedNow(this@MainActivity))
                    BlockPreferences.setWholeAppBlockingEnabled(this@MainActivity, checked)
            }
        }
        wholeCard.addView(wholeMaster)
        wholeCard.addView(label("When enabled, the apps checked below are blocked completely. This switch is separate from short-video blocking. During a scheduled whole-app session, the schedule overrides this switch.", 12, muted, false).apply { setPadding(0, dp(4), 0, dp(6)) })
        addWholeChoice(wholeCard, "Instagram — entire app", BlockPreferences.INSTAGRAM, wholeSelected, forcedNow)
        addWholeChoice(wholeCard, "Facebook — entire app", BlockPreferences.FACEBOOK, wholeSelected, forcedNow)
        addWholeChoice(wholeCard, "YouTube — entire app", BlockPreferences.YOUTUBE, wholeSelected, forcedNow)
        addWholeChoice(wholeCard, "TikTok — entire app", BlockPreferences.TIKTOK, wholeSelected, forcedNow)
        addWholeChoice(wholeCard, "Snapchat — entire app", BlockPreferences.SNAPCHAT, wholeSelected, forcedNow)
        wholeCard.addView(Button(this).apply {
            text = "SAVE WHOLE APP BLOCKS"; styleButton(this, true); isEnabled = !forcedNow
            setOnClickListener {
                if (BlockPreferences.isForcedNow(this@MainActivity)) return@setOnClickListener
                BlockPreferences.setWholeApps(this@MainActivity, wholeChecks.filterValues { it.isChecked }.keys)
                android.widget.Toast.makeText(this@MainActivity, "Whole-app block list saved.", android.widget.Toast.LENGTH_SHORT).show()
            }
        }, matchWrap())

        val safeCard = card(page)
        safeCard.addView(label("🛡  SAFE MODE", 12, violet, true))
        safeCard.addView(label("Block known adult websites", 19, ink, true).apply { setPadding(0, dp(6), 0, dp(3)) })
        safeCard.addView(label("Uses ReelGuard's local VPN to filter a built-in list of adult domains. This is separate from your feed blocker. It cannot identify every explicit image or video inside social apps, and VPNs or encrypted DNS may bypass filtering.", 12, muted, false).apply { setPadding(0, 0, 0, dp(8)) })
        safeCard.addView(Switch(this).apply {
            text = "Enable Safe Mode website protection"; textSize = 14f; setTextColor(ink)
            isChecked = BlockPreferences.safeModeEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                if (checked) {
                    val consent = VpnService.prepare(this@MainActivity)
                    if (consent != null) startActivityForResult(consent, vpnRequestCode)
                    else { BlockPreferences.setSafeModeEnabled(this@MainActivity, true); SafeModeVpnService.start(this@MainActivity); render() }
                } else {
                    BlockPreferences.setSafeModeEnabled(this@MainActivity, false)
                    if (!BlockPreferences.effectiveSafeMode(this@MainActivity)) SafeModeVpnService.stop(this@MainActivity)
                    render()
                }
            }
        })
        safeCard.addView(label("SafeSearch can be enabled in each platform's own settings where supported. Social-app explicit-content detection is best-effort only; Android does not expose reliable image/video classification to this app.", 11, muted, false).apply { setPadding(0, dp(7), 0, 0) })

        val setupCard = card(page)
        setupCard.addView(label("ONE LAST STEP", 12, violet, true))
        setupCard.addView(label("Keep ReelGuard active", 18, ink, true).apply { setPadding(0, dp(6), 0, dp(5)) })
        setupCard.addView(label("Android needs Accessibility permission to recognize the selected feeds. Detection runs locally on your phone.", 13, muted, false))
        setupCard.addView(Button(this).apply {
            text = "OPEN ACCESSIBILITY SETTINGS"; styleButton(this, false)
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, matchWrap())

        page.addView(label("REELGUARD  •  VERSION 1.7", 10, muted, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(18), 0, 0) })
    }

    private fun card(parent: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(17), dp(17), dp(17), dp(17)); background = rounded(panel, 22) }
        parent.addView(c, matchWrap()); return c
    }

    private fun addChoice(parent: LinearLayout, title: String, key: String, selected: Set<String>, locked: Boolean, glyph: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(5), dp(10), dp(5)); background = rounded(panel2, 15) }
        val mark = TextView(this).apply { text = glyph; textSize = 17f; gravity = Gravity.CENTER; setTextColor(cyan); background = rounded(bg, 12) }
        row.addView(mark, LinearLayout.LayoutParams(dp(38), dp(38)))
        val check = CheckBox(this).apply { text = title; textSize = 14f; setTextColor(ink); isChecked = selected.contains(key); isEnabled = !locked; buttonTintList = android.content.res.ColorStateList.valueOf(cyan); setPadding(dp(9), 0, 0, 0) }
        checks[key] = check
        row.addView(check, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        parent.addView(row, matchWrap())
    }

    private fun addWholeChoice(parent: LinearLayout, title: String, key: String, selected: Set<String>, locked: Boolean) {
        val check = CheckBox(this).apply {
            text = title; textSize = 14f; setTextColor(ink); isChecked = selected.contains(key)
            isEnabled = !locked; buttonTintList = android.content.res.ColorStateList.valueOf(violet)
            setPadding(dp(4), dp(5), 0, dp(5))
        }
        wholeChecks[key] = check
        parent.addView(check, matchWrap())
    }

    private fun chooseSchedule() {
        if (BlockPreferences.isForcedNow(this)) { android.widget.Toast.makeText(this, "Forced Mode is active. Edit the schedule after it ends.", android.widget.Toast.LENGTH_LONG).show(); return }
        val startValue = BlockPreferences.scheduleStart(this)
        val startCal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, startValue / 60); set(Calendar.MINUTE, startValue % 60) }
        TimePickerDialog(this, { _, sh, sm ->
            val start = sh * 60 + sm
            val endValue = BlockPreferences.scheduleEnd(this)
            val endCal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, endValue / 60); set(Calendar.MINUTE, endValue % 60) }
            TimePickerDialog(this, { _, eh, em ->
                val end = eh * 60 + em
                if (start == end) { android.widget.Toast.makeText(this, "Start and end times must be different.", android.widget.Toast.LENGTH_LONG).show(); return@TimePickerDialog }
                val choices = arrayOf("Short videos only", "Entire selected apps", "Safe Mode — adult website protection")
                val selected = booleanArrayOf(BlockPreferences.scheduleFeeds(this), BlockPreferences.scheduleWholeApps(this), BlockPreferences.scheduleSafeMode(this))
                android.app.AlertDialog.Builder(this)
                    .setTitle("Choose scheduled protection")
                    .setMultiChoiceItems(choices, selected) { _, which, checked -> selected[which] = checked }
                    .setPositiveButton("SAVE SCHEDULE") { _, _ ->
                        if (!selected.any { it }) {
                            android.widget.Toast.makeText(this, "Choose at least one protection mode.", android.widget.Toast.LENGTH_LONG).show()
                            return@setPositiveButton
                        }
                        BlockPreferences.setSchedule(this, true, start, end,
                            wholeApps = selected[1], safeMode = selected[2], feedMode = selected[0])
                        ScheduleReceiver.scheduleNext(this)
                        if (BlockPreferences.effectiveSafeMode(this)) {
                            val consent = VpnService.prepare(this)
                            if (consent == null) SafeModeVpnService.start(this)
                            else startActivityForResult(consent, vpnScheduleRequestCode)
                        } else if (!BlockPreferences.safeModeEnabled(this)) SafeModeVpnService.stop(this)
                        render()
                        android.widget.Toast.makeText(this, "Daily Forced Mode schedule saved.", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("CANCEL", null)
                    .show()
            }, endCal.get(Calendar.HOUR_OF_DAY), endCal.get(Calendar.MINUTE), false).show()
        }, startCal.get(Calendar.HOUR_OF_DAY), startCal.get(Calendar.MINUTE), false).show()
    }

    @Deprecated("Deprecated by Android; retained for compatibility with the current minSdk")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode || requestCode == vpnScheduleRequestCode) {
            if (resultCode == RESULT_OK) {
                if (requestCode == vpnRequestCode) BlockPreferences.setSafeModeEnabled(this, true)
                SafeModeVpnService.start(this)
            } else {
                if (requestCode == vpnRequestCode) BlockPreferences.setSafeModeEnabled(this, false)
                android.widget.Toast.makeText(this, "Safe Mode needs VPN approval to filter websites.", android.widget.Toast.LENGTH_LONG).show()
            }
            render()
        }
    }

    private fun styleButton(button: Button, primary: Boolean) {
        button.isAllCaps = false; button.textSize = 13f; button.setTextColor(if (primary) Color.rgb(7, 15, 30) else ink)
        button.background = rounded(if (primary) cyan else panel2, 14)
        button.setPadding(dp(12), dp(11), dp(12), dp(11))
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun formatMinutes(value: Int) = String.format("%02d:%02d", value / 60, value % 60)
    private fun isAccessibilityEnabled(): Boolean {
        val expected = "$packageName/${ReelGuardAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) }
}
