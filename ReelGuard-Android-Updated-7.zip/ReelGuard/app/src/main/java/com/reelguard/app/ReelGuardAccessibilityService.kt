package com.reelguard.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock

/** Locally inspects accessibility labels and blocks either selected feeds or whole selected apps. */
class ReelGuardAccessibilityService : AccessibilityService() {
    private var lastBlockedAt = 0L
    private var lastBlockedPackage = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: return
        val app = targetForPackage(packageName) ?: return
        if (event.eventType !in setOf(AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED, AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)) return

        // Best-effort text/label detection only. Android accessibility does not expose reliable
        // visual classification of images or videos, so this cannot guarantee social-feed filtering.
        if (BlockPreferences.effectiveSafeMode(this)) {
            val root = rootInActiveWindow
            if (root != null && containsExplicitWarning(collectSnapshot(root).text)) {
                val now = SystemClock.elapsedRealtime()
                if (packageName != lastBlockedPackage || now - lastBlockedAt >= 2200L) {
                    lastBlockedAt = now; lastBlockedPackage = packageName
                    performGlobalAction(GLOBAL_ACTION_HOME)
                }
                return
            }
        }
        if (!BlockPreferences.effectiveEnabled(this)) return

        // A scheduled lock deliberately selects one blocking style. Outside the schedule,
        // the user's short-feed and whole-app lists can both be active independently.
        val forced = BlockPreferences.isForcedNow(this)
        val wholeAppMode = if (forced) BlockPreferences.scheduleWholeApps(this) && app in BlockPreferences.wholeApps(this)
                           else BlockPreferences.wholeAppBlockingEnabled(this) && app in BlockPreferences.wholeApps(this)
        val feedMode = if (forced) BlockPreferences.scheduleFeeds(this) && app in BlockPreferences.selectedApps(this)
                       else app in BlockPreferences.selectedApps(this)
        val shouldBlock = when {
            wholeAppMode && app in BlockPreferences.wholeApps(this) -> event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedMode -> {
                val root = rootInActiveWindow ?: return
                looksLikeBlockedFeed(app, collectSnapshot(root))
            }
            else -> false
        }
        if (!shouldBlock) return

        val now = SystemClock.elapsedRealtime()
        if (packageName == lastBlockedPackage && now - lastBlockedAt < 2200L) return
        lastBlockedAt = now
        lastBlockedPackage = packageName
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun targetForPackage(pkg: String): String? = when (pkg) {
        "com.instagram.android" -> BlockPreferences.INSTAGRAM
        "com.facebook.katana" -> BlockPreferences.FACEBOOK
        "com.google.android.youtube" -> BlockPreferences.YOUTUBE
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill" -> BlockPreferences.TIKTOK
        "com.snapchat.android" -> BlockPreferences.SNAPCHAT
        else -> null
    }


    private fun containsExplicitWarning(raw: String): Boolean {
        val text = raw.lowercase()
        val phrases = listOf(
            "sexually explicit", "explicit sexual content", "sexual content warning",
            "adult content warning", "pornographic content", "nudity warning",
            "contains nudity", "sexual imagery", "sensitive content: nudity",
            "18+ explicit content", "adult-only content"
        )
        return phrases.any { text.contains(it) }
    }

    private data class UiSnapshot(val text: String, val viewIds: String, val selectedText: String, val clickableText: String)
    private fun countAny(text: String, vararg signals: String) = signals.count { text.contains(it) }

    private fun looksLikeBlockedFeed(app: String, snapshot: UiSnapshot): Boolean {
        val text = snapshot.text.lowercase()
        val ids = snapshot.viewIds.lowercase()
        return when (app) {
            BlockPreferences.INSTAGRAM -> {
                // Instagram's ordinary home/profile/search surfaces can expose Reels labels.
                // Only block inside a dedicated full-screen clips/reel viewer with player evidence.
                val dedicatedViewer = listOf(
                    "clips_viewer_view_pager", "reel_viewer_container", "clips_video_container",
                    "reels_video_viewer", "reel_media_viewer"
                ).any { ids.contains(it) }
                val playerEvidence = listOf("video_player", "clips_video", "reel_video", "media_viewer")
                    .any { ids.contains(it) }
                val engagement = countAny(text, "like", "liked", "comment", "comments", "share", "send")
                val reelContext = text.contains("original audio") || text.contains("use audio") ||
                    text.contains("remix") || text.contains("reels")
                dedicatedViewer && playerEvidence && engagement >= 2 && reelContext
            }
            BlockPreferences.FACEBOOK -> text.contains("reels") &&
                countAny(text, "like", "comment", "share") >= 2 && countAny(text, "original audio", "use audio", "follow") >= 1
            BlockPreferences.YOUTUBE -> text.contains("shorts") &&
                countAny(text, "like", "dislike", "comments", "comment") >= 2 && countAny(text, "share", "remix", "sound", "subscribe") >= 1
            BlockPreferences.TIKTOK -> text.contains("for you") &&
                countAny(text, "like", "comment", "share", "add to favorites", "use this sound") >= 3
            BlockPreferences.SNAPCHAT -> {
                // Snapchat labels and resource IDs vary substantially by release. Check both
                // visible text and view IDs, while requiring a feed/player context so the
                // Discover/Spotlight tab labels in the bottom bar alone do not trigger.
                val spotlightContext = text.contains("spotlight") ||
                    ids.contains("spotlight") || ids.contains("snap_video") ||
                    ids.contains("spotlight_feed")
                val spotlightPlayer = listOf(
                    "spotlight_video", "spotlight_player", "video_player",
                    "snap_video", "spotlight_viewer", "video_feed"
                ).any { ids.contains(it) } ||
                    (text.contains("spotlight") && countAny(text, "like", "reply", "share", "send", "subscribe") >= 2)
                val spotlightEngagement = countAny(text,
                    "like", "reply", "share", "send", "subscribe", "favorite",
                    "add to favorites", "use sound", "original sound")
                val spotlightBlocked = spotlightContext && spotlightPlayer && spotlightEngagement >= 2

                // Discover is Snapchat's publisher/show feed, not the Discover tab icon
                // visible elsewhere. Require a Discover-specific container or a selected
                // Discover destination plus several publisher/story/video signals.
                val discoverContainer = listOf(
                    "discover_feed", "discover_page", "discover_container",
                    "publisher_feed", "content_feed", "shows_feed", "story_feed"
                ).any { ids.contains(it) }
                val discoverSelected = snapshot.selectedText.contains("discover")
                val discoverContext = text.contains("discover") || ids.contains("discover")
                val discoverContentSignals = countAny(text,
                    "subscribe", "episodes", "watch", "publisher", "shows",
                    "stories", "for you", "play", "original series", "more episodes")
                val discoverClickableSignals = countAny(snapshot.clickableText,
                    "subscribe", "watch", "episodes", "show", "story", "discover")
                val discoverBlocked = discoverContext &&
                    (discoverContainer || discoverSelected) &&
                    (discoverContentSignals >= 2 || discoverClickableSignals >= 2)

                spotlightBlocked || discoverBlocked
            }
            else -> false
        }
    }

    private fun collectSnapshot(node: AccessibilityNodeInfo): UiSnapshot {
        val text = StringBuilder()
        val ids = StringBuilder()
        val selected = StringBuilder()
        val clickable = StringBuilder()
        fun visit(current: AccessibilityNodeInfo, depth: Int) {
            if (depth > 22) return
            val label = buildString {
                current.text?.let { append(it).append(' ') }
                current.contentDescription?.let { append(it).append(' ') }
            }
            text.append(label)
            if (current.isSelected || current.isAccessibilityFocused) selected.append(label)
            if (current.isClickable) clickable.append(label)
            current.viewIdResourceName?.let { ids.append(it.substringAfterLast('/')).append(' ') }
            for (i in 0 until current.childCount) {
                val child = current.getChild(i) ?: continue
                visit(child, depth + 1)
                child.recycle()
            }
        }
        visit(node, 0)
        return UiSnapshot(text.toString(), ids.toString(), selected.toString(), clickable.toString())
    }
    override fun onInterrupt() = Unit
}
