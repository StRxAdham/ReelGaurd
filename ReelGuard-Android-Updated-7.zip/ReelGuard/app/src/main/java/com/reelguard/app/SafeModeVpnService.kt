package com.reelguard.app

import android.net.VpnService
import android.content.Intent
import android.os.ParcelFileDescriptor
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.os.Build
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.Locale
import kotlin.concurrent.thread

/** DNS-only local filter. It routes the private DNS endpoint through this TUN and forwards allowed UDP DNS queries. */
class SafeModeVpnService : VpnService() {
    @Volatile private var running = false
    private var tunnel: ParcelFileDescriptor? = null
    private val dnsIp = byteArrayOf(10, 111, 0, 2)
    private val blocked = setOf(
        "pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com", "youporn.com",
        "tube8.com", "spankbang.com", "porn.com", "eporner.com", "hqporner.com", "tnaflix.com",
        "motherless.com", "beeg.com", "daftsex.com", "txxx.com", "sex.com", "adultfriendfinder.com",
        "chaturbate.com", "stripchat.com", "livejasmin.com", "bongacams.com", "cam4.com", "camsoda.com",
        "onlyfans.com", "fansly.com", "manyvids.com", "fapello.com", "rule34.xxx", "nhentai.net",
        "hanime.tv", "hentaihaven.xxx", "literotica.com", "asstr.org", "brazzers.com", "realitykings.com",
        "bangbros.com", "naughtyamerica.com", "mofos.com", "vixen.com", "mylf.com", "teamskeet.com"
    )

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopFilter(); return START_NOT_STICKY }
        if (!running) startFilter()
        return START_STICKY
    }

    private fun startFilter() {
        val channelId = "reelguard_safe_mode"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(channelId, "ReelGuard Safe Mode", NotificationManager.IMPORTANCE_LOW)
        )
        val openApp = PendingIntent.getActivity(this, 9201, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
            .setSmallIcon(com.reelguard.app.R.mipmap.ic_launcher)
            .setContentTitle("ReelGuard Safe Mode is active")
            .setContentText("Filtering known adult website domains")
            .setContentIntent(openApp).setOngoing(true).build()
        else Notification.Builder(this).setSmallIcon(com.reelguard.app.R.mipmap.ic_launcher)
            .setContentTitle("ReelGuard Safe Mode is active")
            .setContentText("Filtering known adult website domains")
            .setContentIntent(openApp).setOngoing(true).build()
        startForeground(9201, notification)
        val config = Builder().setSession("ReelGuard Safe Mode")
            .addAddress("10.111.0.1", 32)
            .addDnsServer("10.111.0.2")
            .addRoute("10.111.0.2", 32)
            .setMtu(1500)
        tunnel = config.establish() ?: return
        running = true
        thread(name = "ReelGuard-DNS") {
            val input = FileInputStream(tunnel!!.fileDescriptor)
            val output = FileOutputStream(tunnel!!.fileDescriptor)
            val buffer = ByteArray(32767)
            while (running) {
                try {
                    val n = input.read(buffer)
                    if (n <= 0) continue
                    val packet = buffer.copyOf(n)
                    if (packet.size < 28 || ((packet[0].toInt() ushr 4) and 0xF) != 4) continue
                    val ihl = (packet[0].toInt() and 0xF) * 4
                    if (packet.size < ihl + 8 || (packet[9].toInt() and 0xFF) != 17) continue
                    val destPort = u16(packet, ihl + 2)
                    if (destPort != 53) continue
                    val dnsStart = ihl + 8
                    val dnsLength = packet.size - dnsStart
                    if (dnsLength < 12) continue
                    val domain = readQuestionName(packet, dnsStart, dnsLength)?.lowercase(Locale.US) ?: continue
                    val answer = if (isBlocked(domain)) makeNxDomain(packet, ihl, dnsStart, dnsLength)
                                 else forwardDns(packet, ihl, dnsStart, dnsLength)
                    if (answer != null) output.write(answer)
                } catch (_: Exception) { if (!running) break }
            }
        }
    }

    private fun isBlocked(domain: String): Boolean = blocked.any { domain == it || domain.endsWith(".$it") }

    private fun forwardDns(packet: ByteArray, ihl: Int, dnsStart: Int, dnsLength: Int): ByteArray? {
        val socket = DatagramSocket()
        return try {
            protect(socket)
            socket.soTimeout = 2500
            val query = packet.copyOfRange(dnsStart, dnsStart + dnsLength)
            socket.send(DatagramPacket(query, query.size, InetAddress.getByName("1.1.1.3"), 53))
            val response = ByteArray(4096)
            val reply = DatagramPacket(response, response.size)
            socket.receive(reply)
            makeIpUdpReply(packet, ihl, response.copyOf(reply.length))
        } catch (_: SocketTimeoutException) { null } finally { socket.close() }
    }

    private fun makeNxDomain(packet: ByteArray, ihl: Int, dnsStart: Int, dnsLength: Int): ByteArray {
        val dns = packet.copyOfRange(dnsStart, dnsStart + dnsLength)
        if (dns.size >= 4) dns[2] = ((dns[2].toInt() or 0x80) and 0xFF).toByte() // QR response
        if (dns.size >= 4) dns[3] = ((dns[3].toInt() and 0xF0) or 0x03).toByte() // NXDOMAIN
        return makeIpUdpReply(packet, ihl, dns)
    }

    private fun makeIpUdpReply(original: ByteArray, ihl: Int, dns: ByteArray): ByteArray {
        val out = ByteArray(ihl + 8 + dns.size)
        // Copy IP header, then swap source and destination addresses.
        System.arraycopy(original, 0, out, 0, ihl)
        for (i in 0..3) { out[12 + i] = original[16 + i]; out[16 + i] = original[12 + i] }
        out[2] = (out.size ushr 8).toByte(); out[3] = out.size.toByte()
        out[6] = 0; out[7] = 0; out[8] = 64
        out[10] = 0; out[11] = 0
        val udp = ihl
        out[udp] = original[udp + 2]; out[udp + 1] = original[udp + 3]
        out[udp + 2] = 0; out[udp + 3] = 53
        val udpLen = 8 + dns.size
        out[udp + 4] = (udpLen ushr 8).toByte(); out[udp + 5] = udpLen.toByte()
        out[udp + 6] = 0; out[udp + 7] = 0
        System.arraycopy(dns, 0, out, udp + 8, dns.size)
        put16(out, 10, checksum(out, 0, ihl))
        return out
    }

    private fun readQuestionName(p: ByteArray, start: Int, len: Int): String? {
        var i = start + 12; val end = start + len; val labels = mutableListOf<String>()
        while (i < end) {
            val n = p[i++].toInt() and 0xFF
            if (n == 0) return labels.joinToString(".")
            if ((n and 0xC0) != 0 || n > 63 || i + n > end) return null
            labels += String(p, i, n, Charsets.US_ASCII); i += n
        }
        return null
    }
    private fun u16(b: ByteArray, i: Int) = ((b[i].toInt() and 255) shl 8) or (b[i + 1].toInt() and 255)
    private fun put16(b: ByteArray, i: Int, v: Int) { b[i] = (v ushr 8).toByte(); b[i + 1] = v.toByte() }
    private fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0L; var i = off
        while (i + 1 < off + len) { sum += u16(b, i); i += 2 }
        if (i < off + len) sum += (b[i].toInt() and 255) shl 8
        while (sum ushr 16 != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    @Suppress("DEPRECATION")
    private fun stopFilter() {
        running = false
        try { tunnel?.close() } catch (_: Exception) {}
        tunnel = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        stopSelf()
    }
    override fun onDestroy() { stopFilter(); super.onDestroy() }

    companion object {
        const val ACTION_STOP = "com.reelguard.app.STOP_SAFE_MODE"
        fun start(context: android.content.Context) = context.startService(Intent(context, SafeModeVpnService::class.java))
        fun stop(context: android.content.Context) = context.startService(Intent(context, SafeModeVpnService::class.java).setAction(ACTION_STOP))
    }
}
