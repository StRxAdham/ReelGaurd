package com.reelguard.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.AlarmManager
import android.app.PendingIntent
import java.util.Calendar

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        refreshSafeMode(context)
        scheduleNext(context)
    }

    companion object {
        const val ACTION_REFRESH = "com.reelguard.app.REFRESH_SCHEDULE"

        fun refreshSafeMode(context: Context) {
            if (BlockPreferences.effectiveSafeMode(context)) {
                if (android.net.VpnService.prepare(context) == null) SafeModeVpnService.start(context)
            } else if (!BlockPreferences.safeModeEnabled(context)) {
                SafeModeVpnService.stop(context)
            }
        }

        fun scheduleNext(context: Context) {
            if (!BlockPreferences.scheduleEnabled(context)) return
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            listOf(BlockPreferences.scheduleStart(context), BlockPreferences.scheduleEnd(context)).forEachIndexed { index, minute ->
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, minute / 60)
                    set(Calendar.MINUTE, minute % 60)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
                }
                val pi = PendingIntent.getBroadcast(
                    context, 7100 + index,
                    Intent(context, ScheduleReceiver::class.java).setAction("com.reelguard.app.ALARM_$index"),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            ScheduleReceiver.refreshSafeMode(context)
            ScheduleReceiver.scheduleNext(context)
        }
    }
}
