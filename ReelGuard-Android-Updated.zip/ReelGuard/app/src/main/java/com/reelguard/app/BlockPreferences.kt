package com.reelguard.app

import android.content.Context
import java.util.Calendar

object BlockPreferences {
    private const val PREFS = "reelguard_settings"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_APPS = "selected_apps"
    private const val KEY_WHOLE_APPS = "whole_apps"
    private const val KEY_WHOLE_APPS_ENABLED = "whole_apps_enabled"
    private const val KEY_SCHEDULE_WHOLE_APPS = "schedule_whole_apps"
    private const val KEY_SCHEDULE_ENABLED = "schedule_enabled"
    private const val KEY_START_MINUTES = "schedule_start_minutes"
    private const val KEY_END_MINUTES = "schedule_end_minutes"

    const val INSTAGRAM = "instagram"
    const val FACEBOOK = "facebook"
    const val YOUTUBE = "youtube"
    const val TIKTOK = "tiktok"
    const val SNAPCHAT = "snapchat"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, enabled: Boolean) { prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply() }
    fun selectedApps(context: Context): Set<String> = prefs(context).getStringSet(KEY_APPS, setOf(INSTAGRAM, YOUTUBE))?.toSet() ?: setOf(INSTAGRAM, YOUTUBE)
    fun setSelectedApps(context: Context, apps: Set<String>) { prefs(context).edit().putStringSet(KEY_APPS, apps.toSet()).apply() }
    fun wholeApps(context: Context): Set<String> = prefs(context).getStringSet(KEY_WHOLE_APPS, emptySet())?.toSet() ?: emptySet()
    fun setWholeApps(context: Context, apps: Set<String>) { prefs(context).edit().putStringSet(KEY_WHOLE_APPS, apps.toSet()).apply() }
    fun wholeAppBlockingEnabled(context: Context) = prefs(context).getBoolean(KEY_WHOLE_APPS_ENABLED, false)
    fun setWholeAppBlockingEnabled(context: Context, enabled: Boolean) { prefs(context).edit().putBoolean(KEY_WHOLE_APPS_ENABLED, enabled).apply() }
    fun scheduleWholeApps(context: Context) = prefs(context).getBoolean(KEY_SCHEDULE_WHOLE_APPS, false)

    fun scheduleEnabled(context: Context) = prefs(context).getBoolean(KEY_SCHEDULE_ENABLED, false)
    fun scheduleStart(context: Context) = prefs(context).getInt(KEY_START_MINUTES, 20 * 60)
    fun scheduleEnd(context: Context) = prefs(context).getInt(KEY_END_MINUTES, 22 * 60)
    fun setSchedule(context: Context, enabled: Boolean, start: Int, end: Int, wholeApps: Boolean = scheduleWholeApps(context)) {
        prefs(context).edit().putBoolean(KEY_SCHEDULE_ENABLED, enabled)
            .putInt(KEY_START_MINUTES, start).putInt(KEY_END_MINUTES, end)
            .putBoolean(KEY_SCHEDULE_WHOLE_APPS, wholeApps).apply()
    }

    fun isForcedNow(context: Context): Boolean {
        if (!scheduleEnabled(context)) return false
        val now = Calendar.getInstance()
        val minute = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val start = scheduleStart(context)
        val end = scheduleEnd(context)
        return if (start < end) minute >= start && minute < end else minute >= start || minute < end
    }
    fun effectiveEnabled(context: Context) = isEnabled(context) || isForcedNow(context)
}
