package com.reelguard.app

import android.app.Activity
import android.app.TimePickerDialog
import java.util.Calendar
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val ink = Color.rgb(31, 35, 40)
    private val muted = Color.rgb(105, 112, 120)
    private val accent = Color.rgb(35, 115, 91)
    private val checks = linkedMapOf<String, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        // Refreshing the screen also updates the accessibility status label.
        if (checks.isNotEmpty()) render()
    }

    private fun render() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(30), dp(24), dp(28))
            setBackgroundColor(Color.rgb(248, 249, 247))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("REELGUARD", 28, ink, true))
        page.addView(label("A calmer feed starts with one small choice.", 15, muted, false).apply {
            setPadding(0, dp(5), 0, dp(22))
        })

        val status = label(
            if (isAccessibilityEnabled()) "● BLOCKER PERMISSION ACTIVE" else "○ ACCESSIBILITY PERMISSION NEEDED",
            12, if (isAccessibilityEnabled()) accent else Color.rgb(176, 104, 39), true
        )
        page.addView(status)

        val forcedNow = BlockPreferences.isForcedNow(this)
        val master = Switch(this).apply {
            text = if (forcedNow) "ReelGuard is locked on (scheduled session)" else "Enable ReelGuard"
            textSize = 17f
            setTextColor(ink)
            isChecked = BlockPreferences.effectiveEnabled(this@MainActivity)
            isEnabled = !forcedNow
            setPadding(0, dp(16), 0, dp(16))
            setOnCheckedChangeListener { _, checked ->
                BlockPreferences.setEnabled(this@MainActivity, checked)
            }
        }
        page.addView(master)

        val scheduleButton = Button(this).apply {
            text = if (BlockPreferences.scheduleEnabled(this@MainActivity)) {
                "EDIT DAILY FORCED SCHEDULE"
            } else "SET DAILY FORCED SCHEDULE"
            setOnClickListener { chooseSchedule() }
        }
        page.addView(scheduleButton, matchWrap())
        if (BlockPreferences.scheduleEnabled(this) && !forcedNow) {
            page.addView(Button(this).apply {
                text = "REMOVE DAILY SCHEDULE"
                setOnClickListener {
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("Remove schedule?")
                        .setMessage("This removes the upcoming daily Forced Mode sessions.")
                        .setNegativeButton("KEEP", null)
                        .setPositiveButton("REMOVE") { _, _ ->
                            BlockPreferences.setSchedule(this@MainActivity, false, BlockPreferences.scheduleStart(this@MainActivity), BlockPreferences.scheduleEnd(this@MainActivity))
                            render()
                        }.show()
                }
            }, matchWrap())
        }
        page.addView(label(
            if (BlockPreferences.scheduleEnabled(this)) {
                "Daily forced window: ${formatMinutes(BlockPreferences.scheduleStart(this))}–${formatMinutes(BlockPreferences.scheduleEnd(this))}. It stays active across app restarts and phone reboots."
            } else "Set a daily time window when ReelGuard is forced on.",
            13, muted, false
        ))

        page.addView(label("CHOOSE WHAT TO BLOCK", 13, muted, true).apply {
            setPadding(0, dp(16), 0, dp(8))
        })
        page.addView(label("ReelGuard checks selected apps for short-video feed screens. Select only the apps you want.", 14, muted, false))

        val selected = BlockPreferences.selectedApps(this)
        addChoice(page, "Instagram Reels", BlockPreferences.INSTAGRAM, selected, forcedNow)
        addChoice(page, "Facebook Reels", BlockPreferences.FACEBOOK, selected, forcedNow)
        addChoice(page, "YouTube Shorts", BlockPreferences.YOUTUBE, selected, forcedNow)
        addChoice(page, "TikTok feed", BlockPreferences.TIKTOK, selected, forcedNow)

        val save = Button(this).apply {
            text = "SAVE SELECTIONS"
            isEnabled = !forcedNow
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
            setOnClickListener {
                if (BlockPreferences.isForcedNow(this@MainActivity)) {
                    android.widget.Toast.makeText(this@MainActivity, "Scheduled Forced Mode is active; settings are locked until it ends.", android.widget.Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                BlockPreferences.setSelectedApps(
                    this@MainActivity,
                    checks.filterValues { it.isChecked }.keys
                )
                android.widget.Toast.makeText(this@MainActivity, "Your choices are saved.", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        page.addView(save, matchWrap())

        val permission = Button(this).apply {
            text = "OPEN ACCESSIBILITY SETTINGS"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        page.addView(permission, matchWrap())

        page.addView(label("HOW IT WORKS", 13, muted, true).apply {
            setPadding(0, dp(22), 0, dp(8))
        })
        page.addView(label(
            "When an enabled app displays a recognizable Reels or Shorts feed, the accessibility service presses Back to leave that screen. It does not uninstall, modify, or sign in to those apps.",
            14, ink, false
        ))
        page.addView(label(
            "Privacy: detection runs on your device. ReelGuard does not request internet access, collect analytics, or transmit screen content.",
            13, muted, false
        ).apply { setPadding(0, dp(14), 0, 0) })
        page.addView(label(
            "Note: app interfaces change frequently. Detection may not catch every feed or may need updating after a target app redesign.",
            13, muted, false
        ).apply { setPadding(0, dp(12), 0, 0) })
    }

    private fun addChoice(
        parent: LinearLayout,
        title: String,
        key: String,
        selected: Set<String>,
        locked: Boolean
    ) {
        val check = CheckBox(this).apply {
            text = title
            textSize = 16f
            setTextColor(ink)
            isChecked = selected.contains(key)
            isEnabled = !locked
            setPadding(0, dp(7), 0, dp(7))
        }
        checks[key] = check
        parent.addView(check)
    }

    private fun chooseSchedule() {
        if (BlockPreferences.isForcedNow(this)) {
            android.widget.Toast.makeText(this, "Forced Mode is active. You can edit the schedule after it ends.", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val startCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, BlockPreferences.scheduleStart(this@MainActivity) / 60)
            set(Calendar.MINUTE, BlockPreferences.scheduleStart(this@MainActivity) % 60)
        }
        TimePickerDialog(this, { _, sh, sm ->
            val start = sh * 60 + sm
            val endCal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, BlockPreferences.scheduleEnd(this@MainActivity) / 60)
                set(Calendar.MINUTE, BlockPreferences.scheduleEnd(this@MainActivity) % 60)
            }
            TimePickerDialog(this, { _, eh, em ->
                val end = eh * 60 + em
                if (start == end) {
                    android.widget.Toast.makeText(this, "Start and end times must be different.", android.widget.Toast.LENGTH_LONG).show()
                    return@TimePickerDialog
                }
                BlockPreferences.setSchedule(this, true, start, end)
                sendBroadcast(Intent(this, ScheduleReceiver::class.java).setAction(ScheduleReceiver.ACTION_REFRESH))
                render()
                android.widget.Toast.makeText(this, "Daily Forced Mode schedule saved.", android.widget.Toast.LENGTH_SHORT).show()
            }, endCal.get(Calendar.HOUR_OF_DAY), endCal.get(Calendar.MINUTE), false).show()
        }, startCal.get(Calendar.HOUR_OF_DAY), startCal.get(Calendar.MINUTE), false).show()
    }

    private fun formatMinutes(value: Int): String = String.format("%02d:%02d", value / 60, value % 60)

    private fun isAccessibilityEnabled(): Boolean {
        val expected = "$packageName/${ReelGuardAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(12) }
}
