package com.reelguard.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock

class ReelGuardAccessibilityService : AccessibilityService() {
    private var lastBlockedAt = 0L
    private var lastBlockedScreen = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !BlockPreferences.effectiveEnabled(this)) return
        val packageName = event.packageName?.toString() ?: return
        val app = targetForPackage(packageName) ?: return
        if (app !in BlockPreferences.selectedApps(this)) return

        // Only inspect meaningful window/content changes, not every tiny UI event.
        if (event.eventType !in setOf(
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            )) return

        val root = rootInActiveWindow ?: return
        val text = collectVisibleText(root).lowercase()
        if (!looksLikeBlockedFeed(app, text)) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastBlockedAt < 1800 && lastBlockedScreen == packageName) return
        lastBlockedAt = now
        lastBlockedScreen = packageName
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun targetForPackage(pkg: String): String? = when (pkg) {
        "com.instagram.android" -> BlockPreferences.INSTAGRAM
        "com.facebook.katana" -> BlockPreferences.FACEBOOK
        "com.google.android.youtube" -> BlockPreferences.YOUTUBE
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill" -> BlockPreferences.TIKTOK
        else -> null
    }

    private fun looksLikeBlockedFeed(app: String, text: String): Boolean {
        val hasVideoActions = listOf("like", "comment", "share").count { text.contains(it) } >= 2
        return when (app) {
            // Require multiple feed-specific signals together; a tab/menu label alone is not enough.
            BlockPreferences.INSTAGRAM -> text.contains("reels") && hasVideoActions &&
                (text.contains("audio") || text.contains("original") || text.contains("remix"))
            BlockPreferences.FACEBOOK -> text.contains("reels") && hasVideoActions &&
                (text.contains("sponsored") || text.contains("audio") || text.contains("original audio"))
            BlockPreferences.YOUTUBE -> text.contains("shorts") && hasVideoActions &&
                (text.contains("subscribe") || text.contains("remix") || text.contains("sound"))
            // TikTok's For You screen is itself the short-video feed. Require the video action rail too.
            BlockPreferences.TIKTOK -> (text.contains("for you") || text.contains("following")) && hasVideoActions
            else -> false
        }
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo): String {
        val out = StringBuilder()
        fun visit(current: AccessibilityNodeInfo, depth: Int) {
            if (depth > 16) return
            current.text?.let { out.append(it).append(' ') }
            current.contentDescription?.let { out.append(it).append(' ') }
            for (i in 0 until current.childCount) {
                val child = current.getChild(i) ?: continue
                visit(child, depth + 1)
                child.recycle()
            }
        }
        visit(node, 0)
        return out.toString()
    }

    override fun onInterrupt() = Unit
}
