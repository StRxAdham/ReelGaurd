package com.reelguard.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock

/**
 * Conservative feed detector. It deliberately requires several simultaneous,
 * app-specific signals to avoid blocking ordinary app screens.
 */
class ReelGuardAccessibilityService : AccessibilityService() {
    private var lastBlockedAt = 0L
    private var lastBlockedPackage = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !BlockPreferences.effectiveEnabled(this)) return
        val packageName = event.packageName?.toString() ?: return
        val app = targetForPackage(packageName) ?: return
        if (app !in BlockPreferences.selectedApps(this)) return
        if (event.eventType !in setOf(
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            )) return

        val root = rootInActiveWindow ?: return
        val snapshot = collectSnapshot(root).lowercase()
        if (!looksLikeBlockedFeed(app, snapshot)) return

        val now = SystemClock.elapsedRealtime()
        // A cooldown prevents repeated HOME actions while the app is animating away.
        if (packageName == lastBlockedPackage && now - lastBlockedAt < 2500L) return
        lastBlockedAt = now
        lastBlockedPackage = packageName
        // Back can behave like navigation/scroll in some feeds. HOME actually leaves the app.
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun targetForPackage(pkg: String): String? = when (pkg) {
        "com.instagram.android" -> BlockPreferences.INSTAGRAM
        "com.facebook.katana" -> BlockPreferences.FACEBOOK
        "com.google.android.youtube" -> BlockPreferences.YOUTUBE
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill" -> BlockPreferences.TIKTOK
        "com.snapchat.android" -> BlockPreferences.SNAPCHAT
        else -> null
    }

    private fun hasAll(text: String, vararg signals: String) = signals.all { text.contains(it) }
    private fun countAny(text: String, vararg signals: String) = signals.count { text.contains(it) }

    private fun looksLikeBlockedFeed(app: String, text: String): Boolean = when (app) {
        // Instagram Reels viewer: require the Reels context, the action rail, and audio/remix context.
        BlockPreferences.INSTAGRAM -> hasAll(text, "reels") &&
            countAny(text, "like", "liked", "comment", "comments") >= 2 &&
            countAny(text, "share", "send", "audio", "original audio", "use audio", "remix") >= 2

        BlockPreferences.FACEBOOK -> hasAll(text, "reels") &&
            countAny(text, "like", "comment", "share") >= 2 &&
            countAny(text, "audio", "original audio", "sponsored", "follow") >= 1

        // Shorts viewer has a distinct Shorts label plus its vertical-video action rail.
        BlockPreferences.YOUTUBE -> hasAll(text, "shorts") &&
            countAny(text, "like", "dislike", "comments", "comment") >= 2 &&
            countAny(text, "share", "remix", "sound", "subscribe") >= 1

        // TikTok For You viewer: require the feed tabs and multiple video actions.
        BlockPreferences.TIKTOK -> hasAll(text, "for you", "following") &&
            countAny(text, "like", "comment", "share", "add to favorites", "use this sound") >= 3

        // Spotlight is distinct from Snapchat chat/camera: require Spotlight and video actions.
        BlockPreferences.SNAPCHAT -> hasAll(text, "spotlight") &&
            countAny(text, "subscribe", "follow", "creator") >= 1 &&
            countAny(text, "like", "comment", "share", "send", "sound") >= 2

        else -> false
    }

    private fun collectSnapshot(node: AccessibilityNodeInfo): String {
        val out = StringBuilder()
        fun visit(current: AccessibilityNodeInfo, depth: Int) {
            if (depth > 18) return
            current.text?.let { out.append(it).append(' ') }
            current.contentDescription?.let { out.append(it).append(' ') }
            current.viewIdResourceName?.let { out.append(it.substringAfterLast('/')).append(' ') }
            for (i in 0 until current.childCount) {
                val child = current.getChild(i) ?: continue
                visit(child, depth + 1)
                child.recycle()
            }
        }
        visit(node, 0)
        return out.toString()
    }

    override fun onInterrupt() = Unit
}
