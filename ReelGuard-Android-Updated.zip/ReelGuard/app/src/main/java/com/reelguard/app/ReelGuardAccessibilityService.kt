package com.reelguard.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock

/** Locally inspects accessibility labels and blocks either selected feeds or whole selected apps. */
class ReelGuardAccessibilityService : AccessibilityService() {
    private var lastBlockedAt = 0L
    private var lastBlockedPackage = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !BlockPreferences.effectiveEnabled(this)) return
        val packageName = event.packageName?.toString() ?: return
        val app = targetForPackage(packageName) ?: return
        if (event.eventType !in setOf(AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED, AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)) return

        // A scheduled lock deliberately selects one blocking style. Outside the schedule,
        // the user's short-feed and whole-app lists can both be active independently.
        val forced = BlockPreferences.isForcedNow(this)
        val wholeAppMode = if (forced) BlockPreferences.scheduleWholeApps(this) && app in BlockPreferences.wholeApps(this)
                           else BlockPreferences.wholeAppBlockingEnabled(this) && app in BlockPreferences.wholeApps(this)
        val feedMode = if (forced) !BlockPreferences.scheduleWholeApps(this) && app in BlockPreferences.selectedApps(this)
                       else app in BlockPreferences.selectedApps(this)
        val shouldBlock = when {
            wholeAppMode && app in BlockPreferences.wholeApps(this) -> event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedMode -> {
                val root = rootInActiveWindow ?: return
                looksLikeBlockedFeed(app, collectSnapshot(root))
            }
            else -> false
        }
        if (!shouldBlock) return

        val now = SystemClock.elapsedRealtime()
        if (packageName == lastBlockedPackage && now - lastBlockedAt < 2200L) return
        lastBlockedAt = now
        lastBlockedPackage = packageName
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun targetForPackage(pkg: String): String? = when (pkg) {
        "com.instagram.android" -> BlockPreferences.INSTAGRAM
        "com.facebook.katana" -> BlockPreferences.FACEBOOK
        "com.google.android.youtube" -> BlockPreferences.YOUTUBE
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill" -> BlockPreferences.TIKTOK
        "com.snapchat.android" -> BlockPreferences.SNAPCHAT
        else -> null
    }

    private data class UiSnapshot(val text: String, val viewIds: String)
    private fun countAny(text: String, vararg signals: String) = signals.count { text.contains(it) }

    private fun looksLikeBlockedFeed(app: String, snapshot: UiSnapshot): Boolean {
        val text = snapshot.text.lowercase()
        val ids = snapshot.viewIds.lowercase()
        return when (app) {
            BlockPreferences.INSTAGRAM -> {
                // Instagram's ordinary home/profile/search surfaces can expose Reels labels.
                // Only block inside a dedicated full-screen clips/reel viewer with player evidence.
                val dedicatedViewer = listOf(
                    "clips_viewer_view_pager", "reel_viewer_container", "clips_video_container",
                    "reels_video_viewer", "reel_media_viewer"
                ).any { ids.contains(it) }
                val playerEvidence = listOf("video_player", "clips_video", "reel_video", "media_viewer")
                    .any { ids.contains(it) }
                val engagement = countAny(text, "like", "liked", "comment", "comments", "share", "send")
                val reelContext = text.contains("original audio") || text.contains("use audio") ||
                    text.contains("remix") || text.contains("reels")
                dedicatedViewer && playerEvidence && engagement >= 2 && reelContext
            }
            BlockPreferences.FACEBOOK -> text.contains("reels") &&
                countAny(text, "like", "comment", "share") >= 2 && countAny(text, "original audio", "use audio", "follow") >= 1
            BlockPreferences.YOUTUBE -> text.contains("shorts") &&
                countAny(text, "like", "dislike", "comments", "comment") >= 2 && countAny(text, "share", "remix", "sound", "subscribe") >= 1
            BlockPreferences.TIKTOK -> text.contains("for you") &&
                countAny(text, "like", "comment", "share", "add to favorites", "use this sound") >= 3
            BlockPreferences.SNAPCHAT -> {
                // Spotlight is distinct from Stories/Chat: require Spotlight context plus
                // a video/player surface and multiple creator engagement controls.
                val spotlightId = ids.contains("spotlight") &&
                    listOf("video", "player", "viewer", "feed").any { ids.contains(it) }
                val spotlightText = text.contains("spotlight")
                val playerSurface = listOf("spotlight_video", "spotlight_player", "video_player", "snap_video")
                    .any { ids.contains(it) }
                val engagement = countAny(text, "subscribe", "share", "send", "reply", "like", "favorite", "sound")
                val creatorContext = text.contains("subscribe") || text.contains("spotlight") || text.contains("original sound")
                (spotlightId || (spotlightText && playerSurface)) && engagement >= 2 && creatorContext
            }
            else -> false
        }
    }

    private fun collectSnapshot(node: AccessibilityNodeInfo): UiSnapshot {
        val text = StringBuilder(); val ids = StringBuilder()
        fun visit(current: AccessibilityNodeInfo, depth: Int) {
            if (depth > 18) return
            current.text?.let { text.append(it).append(' ') }
            current.contentDescription?.let { text.append(it).append(' ') }
            current.viewIdResourceName?.let { ids.append(it.substringAfterLast('/')).append(' ') }
            for (i in 0 until current.childCount) {
                val child = current.getChild(i) ?: continue
                visit(child, depth + 1); child.recycle()
            }
        }
        visit(node, 0)
        return UiSnapshot(text.toString(), ids.toString())
    }
    override fun onInterrupt() = Unit
}
