# ReelGuard

A free, minimal Android app that uses Android Accessibility Services to leave selected short-video feeds.

## Features

- Select Instagram Reels, Facebook Reels, YouTube Shorts, and TikTok feed independently.
- Master on/off switch.
- No ads, subscription, analytics, or network permission.
- Local-only screen-text inspection.

## Requirements

- Android Studio Ladybug or newer (or a compatible recent release).
- JDK 17.
- Android SDK Platform 35 installed.
- Android device running Android 8.0 (API 26) or newer.

## Open and build

1. Extract `ReelGuard-Android.zip`.
2. In Android Studio choose **Open** and select the extracted `ReelGuard` folder.
3. Allow Gradle sync to finish. Install Android SDK Platform 35 if prompted.
4. Connect an Android device with USB debugging enabled, or start an emulator.
5. Press **Run** (or use **Build > Build Bundle(s) / APK(s) > Build APK(s)**).
6. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

Command-line build (from the project root, with Gradle installed):

```bash
gradle assembleDebug
```

This project intentionally does not bundle the Gradle wrapper JAR. Android Studio can import it using its configured Gradle installation, or you can generate a wrapper with `gradle wrapper`.

## Enable the blocker

1. Open ReelGuard.
2. Select the apps you want to block and tap **Save selections**.
3. Tap **Open Accessibility Settings**.
4. Find **ReelGuard content blocker** and enable it.
5. Review Android's accessibility disclosure and confirm. Return to ReelGuard.
6. Keep the master switch enabled.

Android may show an ongoing accessibility indicator. This is expected. Disable the service at any time from Android Accessibility Settings.

## How detection works

The service checks visible accessibility text only while one of the selected target apps is in the foreground. When a configured feed keyword is detected, it performs Android's Back action. It does not click ads, interact with accounts, or modify target apps.

Detection is heuristic and depends on the target app exposing useful accessibility labels. Instagram/Facebook/YouTube can change labels or layouts; TikTok's "For You" and "Following" labels can also vary by language or app version. The current implementation uses English keywords and package IDs for the standard global app builds. Regional variants, cloned apps, or localized interfaces may need code changes. It is not a guaranteed or tamper-proof blocker.

## Permissions and privacy

- The app declares an Accessibility Service so it can inspect accessible UI labels and navigate back from matching screens.
- It does **not** request INTERNET, overlay, usage access, contacts, storage, microphone, or camera permissions.
- Settings are stored in private app preferences.
- Visible UI text is processed locally and is not saved or transmitted.

Accessibility access is powerful. Enable it only if you understand and trust this app. This project is intended for your own device and personal digital-wellbeing use.

## Customization

Target package IDs and keyword matching are in:

`app/src/main/java/com/reelguard/app/ReelGuardAccessibilityService.kt`

App selections and local settings are in:

`app/src/main/java/com/reelguard/app/BlockPreferences.kt`

## License

Starter project provided for personal use and modification. Review the licenses and policies of the target apps and Android before distributing.


## Build a downloadable APK for free with GitHub Actions

This repository includes `.github/workflows/build-apk.yml`.

1. Create a free GitHub account (if needed) and create a **public** repository named `ReelGuard`.
2. Upload the contents of this project folder to that repository, including the hidden `.github` folder.
3. Open the repository's **Actions** tab.
4. Select **Build ReelGuard APK**, then **Run workflow** (or push to `main`/`master` to trigger it).
5. When the workflow finishes successfully, open its run page and find **Artifacts**.
6. Download `ReelGuard-debug-apk`, unzip it, and install `app-debug.apk` on your Android phone.

The APK is a debug build and is suitable for personal testing. Android may ask you to allow installation from your browser or file manager. Only install APKs you built yourself or trust. GitHub artifact downloads are retained for 30 days by this workflow.
