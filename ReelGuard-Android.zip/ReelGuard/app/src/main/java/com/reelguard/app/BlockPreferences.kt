package com.reelguard.app

import android.content.Context

object BlockPreferences {
    private const val PREFS = "reelguard_settings"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_APPS = "selected_apps"

    const val INSTAGRAM = "instagram"
    const val FACEBOOK = "facebook"
    const val YOUTUBE = "youtube"
    const val TIKTOK = "tiktok"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun selectedApps(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_APPS, setOf(INSTAGRAM, YOUTUBE))?.toSet()
            ?: setOf(INSTAGRAM, YOUTUBE)

    fun setSelectedApps(context: Context, apps: Set<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY_APPS, apps.toSet()).apply()
    }
}
