package com.reelguard.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val ink = Color.rgb(31, 35, 40)
    private val muted = Color.rgb(105, 112, 120)
    private val accent = Color.rgb(35, 115, 91)
    private val checks = linkedMapOf<String, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        // Refreshing the screen also updates the accessibility status label.
        if (checks.isNotEmpty()) render()
    }

    private fun render() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(30), dp(24), dp(28))
            setBackgroundColor(Color.rgb(248, 249, 247))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("REELGUARD", 28, ink, true))
        page.addView(label("A calmer feed starts with one small choice.", 15, muted, false).apply {
            setPadding(0, dp(5), 0, dp(22))
        })

        val status = label(
            if (isAccessibilityEnabled()) "● BLOCKER PERMISSION ACTIVE" else "○ ACCESSIBILITY PERMISSION NEEDED",
            12, if (isAccessibilityEnabled()) accent else Color.rgb(176, 104, 39), true
        )
        page.addView(status)

        val master = Switch(this).apply {
            text = "Enable ReelGuard"
            textSize = 17f
            setTextColor(ink)
            isChecked = BlockPreferences.isEnabled(this@MainActivity)
            setPadding(0, dp(16), 0, dp(16))
            setOnCheckedChangeListener { _, checked ->
                BlockPreferences.setEnabled(this@MainActivity, checked)
            }
        }
        page.addView(master)

        page.addView(label("CHOOSE WHAT TO BLOCK", 13, muted, true).apply {
            setPadding(0, dp(16), 0, dp(8))
        })
        page.addView(label("ReelGuard checks selected apps for short-video feed screens. Select only the apps you want.", 14, muted, false))

        val selected = BlockPreferences.selectedApps(this)
        addChoice(page, "Instagram Reels", BlockPreferences.INSTAGRAM, selected)
        addChoice(page, "Facebook Reels", BlockPreferences.FACEBOOK, selected)
        addChoice(page, "YouTube Shorts", BlockPreferences.YOUTUBE, selected)
        addChoice(page, "TikTok feed", BlockPreferences.TIKTOK, selected)

        val save = Button(this).apply {
            text = "SAVE SELECTIONS"
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
            setOnClickListener {
                BlockPreferences.setSelectedApps(
                    this@MainActivity,
                    checks.filterValues { it.isChecked }.keys
                )
                android.widget.Toast.makeText(this@MainActivity, "Your choices are saved.", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        page.addView(save, matchWrap())

        val permission = Button(this).apply {
            text = "OPEN ACCESSIBILITY SETTINGS"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        page.addView(permission, matchWrap())

        page.addView(label("HOW IT WORKS", 13, muted, true).apply {
            setPadding(0, dp(22), 0, dp(8))
        })
        page.addView(label(
            "When an enabled app displays a recognizable Reels or Shorts feed, the accessibility service presses Back to leave that screen. It does not uninstall, modify, or sign in to those apps.",
            14, ink, false
        ))
        page.addView(label(
            "Privacy: detection runs on your device. ReelGuard does not request internet access, collect analytics, or transmit screen content.",
            13, muted, false
        ).apply { setPadding(0, dp(14), 0, 0) })
        page.addView(label(
            "Note: app interfaces change frequently. Detection may not catch every feed or may need updating after a target app redesign.",
            13, muted, false
        ).apply { setPadding(0, dp(12), 0, 0) })
    }

    private fun addChoice(
        parent: LinearLayout,
        title: String,
        key: String,
        selected: Set<String>
    ) {
        val check = CheckBox(this).apply {
            text = title
            textSize = 16f
            setTextColor(ink)
            isChecked = selected.contains(key)
            setPadding(0, dp(7), 0, dp(7))
        }
        checks[key] = check
        parent.addView(check)
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = "$packageName/${ReelGuardAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(12) }
}
