package com.reelguard.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock

class ReelGuardAccessibilityService : AccessibilityService() {
    private var lastBlockedAt = 0L
    private var lastBlockedScreen = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !BlockPreferences.isEnabled(this)) return

        val packageName = event.packageName?.toString() ?: return
        val app = targetForPackage(packageName) ?: return
        if (app !in BlockPreferences.selectedApps(this)) return

        val root = rootInActiveWindow ?: event.source
        val text = buildString {
            append(event.text.joinToString(" "))
            append(' ')
            append(event.contentDescription ?: "")
            if (root != null) append(' ').append(collectVisibleText(root))
        }.lowercase()

        if (!looksLikeBlockedFeed(app, text)) return

        val now = SystemClock.elapsedRealtime()
        // Avoid repeatedly pressing Back while the same screen is animating.
        if (now - lastBlockedAt < 1400 && lastBlockedScreen == packageName) return

        lastBlockedAt = now
        lastBlockedScreen = packageName
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun targetForPackage(pkg: String): String? = when (pkg) {
        "com.instagram.android" -> BlockPreferences.INSTAGRAM
        "com.facebook.katana" -> BlockPreferences.FACEBOOK
        "com.google.android.youtube" -> BlockPreferences.YOUTUBE
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill" -> BlockPreferences.TIKTOK
        else -> null
    }

    private fun looksLikeBlockedFeed(app: String, text: String): Boolean = when (app) {
        BlockPreferences.INSTAGRAM ->
            text.contains("reels") || text.contains("reel video")
        BlockPreferences.FACEBOOK ->
            text.contains("reels") || text.contains("reel")
        BlockPreferences.YOUTUBE ->
            text.contains("shorts") || text.contains("short video")
        BlockPreferences.TIKTOK ->
            // TikTok's main For You feed is itself the short-video feed.
            text.contains("for you") || text.contains("following")
        else -> false
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo): String {
        val out = StringBuilder()
        fun visit(current: AccessibilityNodeInfo, depth: Int) {
            if (depth > 18) return
            current.text?.let { out.append(it).append(' ') }
            current.contentDescription?.let { out.append(it).append(' ') }
            for (i in 0 until current.childCount) {
                val child = current.getChild(i) ?: continue
                visit(child, depth + 1)
                child.recycle()
            }
        }
        visit(node, 0)
        return out.toString()
    }

    override fun onInterrupt() = Unit
}
